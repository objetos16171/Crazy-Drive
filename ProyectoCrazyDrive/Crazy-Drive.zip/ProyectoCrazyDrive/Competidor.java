import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Competidor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Competidor extends Actor
{
    /**
     * Act - do whatever the Competidor wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
    
    public int checkIfTouchEstrella()
    {
        return 0;
    }
    
    public int checkIfTouchObstaculo()
    {
        return 0;
    }
    
    public void cambiaVelocidad(int cant)
    {   
    }
    
    public int checaSiChoco()
    {
        return 0;
    }
    
    public int checkIfTouchBala()
    {
        return 0;
    }
}
